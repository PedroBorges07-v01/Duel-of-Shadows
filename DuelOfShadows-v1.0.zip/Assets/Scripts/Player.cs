using UnityEngine;
using UnityEngine.InputSystem;

public class Player : MonoBehaviour
{
    Rigidbody2D _playerRb;
    float _xDir;
    [SerializeField] float speedX;
    [SerializeField] float jumpForce;
    [SerializeField] private Animator playerSpriteAnimator;
    [SerializeField] Transform groundCheck;
    [SerializeField] LayerMask groundLayer;
    [SerializeField] Vector2 groundCheckSize = new Vector2(0.5f, 0.1f);
    [SerializeField] int maxJumps = 2;
    private int _jumpsRemaining;
    private bool _isGrounded;
    private SpriteRenderer _spriteRenderer;
    public float CurrentMoveInput => _xDir;
    public event System.Action JumpPerformed;


    
    void Awake()
    {
        _playerRb = GetComponent<Rigidbody2D>();
        _jumpsRemaining = maxJumps;
        _spriteRenderer = GetComponentInChildren<SpriteRenderer>();
        
    }

    void OnMove(InputValue inputValue)
    {
        _xDir = inputValue.Get<Vector2>().x;
    }

   void OnJump(InputValue inputValue)
    {
        if (inputValue.isPressed && _jumpsRemaining > 0)
        {
            _playerRb.linearVelocityY = 0f;

            _playerRb.AddForce(
                Vector2.up * jumpForce,
                ForceMode2D.Impulse
            );

            _jumpsRemaining--;

            JumpPerformed?.Invoke();
    }
    }

    void MovePlayer()
    {
        _playerRb.linearVelocityX = _xDir * speedX;
        bool isRunning = Mathf.Abs(_playerRb.linearVelocityX) > Mathf.Epsilon;
        playerSpriteAnimator.SetBool(name:"IsRunning", isRunning);

        if(_xDir > 0.01f)
        {
            _spriteRenderer.flipX = false;
        }
        else if(_xDir < -0.01f)
        {
            _spriteRenderer.flipX = true;
        }
            
    }

    void CheckGround()
    {
        _isGrounded = Physics2D.OverlapBox(groundCheck.position, groundCheckSize, 0f, groundLayer);

        if (_isGrounded && _playerRb.linearVelocityY <= 0.01f)
        {
            _jumpsRemaining = maxJumps;
        }   
    }

    // Update is called once per frame
    void FixedUpdate()
    {
        MovePlayer();
        CheckGround();
    }
}