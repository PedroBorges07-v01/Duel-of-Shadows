
using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public struct PlayerCommand
{
    public float moveInput;
    public bool jumpPressed;

    public PlayerCommand(float moveInput, bool jumpPressed)
    {
        this.moveInput = moveInput;
        this.jumpPressed = jumpPressed;
    }
}

public class PlayerRecorder : MonoBehaviour
{
    private Player player;

    private List<PlayerCommand> recordedCommands =
        new List<PlayerCommand>();

    private bool isRecording;
    private bool pendingJump;

    public IReadOnlyList<PlayerCommand> RecordedCommands =>
        recordedCommands;

    public Vector2 StartPosition { get; private set; }

    void Awake()
    {
        player = GetComponent<Player>();
    }

    void OnEnable()
    {
        if (player != null)
            player.JumpPerformed += RegisterJump;
    }

    void OnDisable()
    {
        if (player != null)
            player.JumpPerformed -= RegisterJump;
    }

    void RegisterJump()
    {
        if (isRecording)
            pendingJump = true;
    }

    public void StartRecording()
    {
        recordedCommands.Clear();

        pendingJump = false;
        StartPosition = transform.position;

        isRecording = true;
    }

    public void StopRecording()
    {
        isRecording = false;
    }

    void FixedUpdate()
    {
        if (!isRecording)
            return;

        PlayerCommand command = new PlayerCommand(
            player.CurrentMoveInput,
            pendingJump
        );

        recordedCommands.Add(command);

        pendingJump = false;
    }
}
