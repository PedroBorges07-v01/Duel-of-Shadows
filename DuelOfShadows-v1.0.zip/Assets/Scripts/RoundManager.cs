using UnityEngine;
using UnityEngine.InputSystem;
using TMPro;

public class RoundManager : MonoBehaviour
{
    [Header("References")]
    [SerializeField] private PlayerRecorder playerRecorder;
    [SerializeField] private GameObject shadowPrefab;
    [SerializeField] private Transform arenaCenter;
    [SerializeField] private PlayerInput playerInput;
    [SerializeField] private TMP_Text startMessage;

    [Header("Round Settings")]
    [SerializeField] private float roundDuration = 10f;

    private float roundTimer;
    private bool waitingToStart = true;
    private bool roundFinished;

    void Start()
    {
        // Impede o jogador de se movimentar antes do início.
        playerInput.enabled = false;

        // Exibe a mensagem inicial.
        startMessage.gameObject.SetActive(true);
    }

    void Update()
    {
        // Aguarda o jogador pressionar uma tecla.
        if (waitingToStart)
        {
            if (Keyboard.current != null &&
                Keyboard.current.anyKey.wasPressedThisFrame)
            {
                StartRound();
            }

            return;
        }

        if (roundFinished)
            return;

        // Conta os 10 segundos da rodada.
        roundTimer += Time.deltaTime;

        if (roundTimer >= roundDuration)
        {
            FinishRound();
        }
    }

    void StartRound()
    {
        waitingToStart = false;

        startMessage.gameObject.SetActive(false);

        playerInput.enabled = true;

        roundTimer = 0f;

        playerRecorder.StartRecording();

        Debug.Log("Rodada iniciada!");
    }

    void FinishRound()
    {
        roundFinished = true;

        playerRecorder.StopRecording();

        Vector3 playerStart = playerRecorder.StartPosition;

        float centerX = arenaCenter.position.x;

        float mirroredX = (2f * centerX) - playerStart.x;

        Vector3 shadowStart = new Vector3(
            mirroredX,
            playerStart.y,
            playerStart.z
        );

        GameObject shadow = Instantiate(
            shadowPrefab,
            shadowStart,
            Quaternion.identity
        );

        ShadowController controller =
            shadow.GetComponent<ShadowController>();

        controller.PlayRecording(
            playerRecorder.RecordedCommands
        );

        Debug.Log("Gravação finalizada! Sombra criada.");
    }
}

