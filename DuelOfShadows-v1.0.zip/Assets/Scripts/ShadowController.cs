
using System.Collections.Generic;
using UnityEngine;

public class ShadowController : MonoBehaviour
{
    [Header("Movement")]
    [SerializeField] private float speedX = 5f;
    [SerializeField] private float jumpForce = 8f;
    [SerializeField] private int maxJumps = 2;

    [Header("Ground Check")]
    [SerializeField] private Transform groundCheck;
    [SerializeField] private LayerMask groundLayer;
    [SerializeField] private Vector2 groundCheckSize =
        new Vector2(0.5f, 0.1f);

    [Header("Visual")]
    [SerializeField] private Animator shadowAnimator;

    private Rigidbody2D rb;
    private SpriteRenderer spriteRenderer;

    private List<PlayerCommand> commands;

    private int currentCommand;
    private int jumpsRemaining;

    private bool isGrounded;
    private bool isPlaying;

    void Awake()
    {
        rb = GetComponent<Rigidbody2D>();

        spriteRenderer = GetComponentInChildren<SpriteRenderer>();

        jumpsRemaining = maxJumps;
    }

    public void PlayRecording(
        IReadOnlyList<PlayerCommand> recordedCommands)
    {
        if (recordedCommands == null || recordedCommands.Count == 0)
            return;

        commands = new List<PlayerCommand>(recordedCommands);

        currentCommand = 0;
        jumpsRemaining = maxJumps;
        isPlaying = true;
    }

    void FixedUpdate()
    {
        if (!isPlaying)
            return;

        CheckGround();

        if (isGrounded && rb.linearVelocityY <= 0.01f)
        {
            jumpsRemaining = maxJumps;
        }

        // Verifica se ainda existem comandos.
        if (currentCommand >= commands.Count)
        {
            rb.linearVelocityX = 0f;
            isPlaying = false;
            return;
        }

        // Obtém o próximo comando gravado.
        PlayerCommand command = commands[currentCommand];

        currentCommand++;

        // Executa a movimentação horizontal.
        rb.linearVelocityX = -command.moveInput * speedX;

        // Atualiza a direção do personagem.
        if (command.moveInput > 0.01f)
            spriteRenderer.flipX = true;
        else if (command.moveInput < -0.01f)
            spriteRenderer.flipX = false;

        // Executa o pulo somente se permitido.
        if (command.jumpPressed && jumpsRemaining > 0)
        {
            rb.linearVelocityY = 0f;

            rb.AddForce(
                Vector2.up * jumpForce,
                ForceMode2D.Impulse
            );

            jumpsRemaining--;
        }

        // Atualiza a animação.
        if (shadowAnimator != null)
        {
            bool isRunning = Mathf.Abs(command.moveInput) > 0.01f;

            shadowAnimator.SetBool("IsRunning", isRunning);
        }
    }

    void CheckGround()
    {
        isGrounded = Physics2D.OverlapBox(
            groundCheck.position,
            groundCheckSize,
            0f,
            groundLayer
        );
    }
}
